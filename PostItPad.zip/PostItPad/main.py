import tkinter as tk
import time as t
from tkinter import *
#REM: USE PYTHON -M AUTO_PY_TO_EXE UNLESS YOU'RE A SPEC ED KID.
#nvm we're on pyinstaller now.
global window 
global va
class Mainitee:
    def __init__(self):  
        pass
    def getcontent(self):
        val = self.tex.get("1.0", "end-1c")
        if val == "write":
            self.mainline.config(text="Write the text of your file here, and submit when done!")
            self.tex.delete("1.0","end-1c")
            self.rutton.config(text="Wrap It Up!", command = self.get2)
        if val == "open":
            self.mainline.config(text="Write the name of the file you wish to open (PRO TIP: Include the extension)")
            self.tex.delete("1.0","end-1c")
            self.rutton.config(text="Enter", command=self.open)
    def main(self):
        global window
        window = tk.Tk()  
        window.title("Post It Pad")
        window.geometry("500x500")
        self.mainline = tk.Label(  
            text="Type 'write' to write to a new file or 'open' to open an existing one!",
            foreground='blue'
        )
        self.mainline.pack()
        self.tex = tk.Text() 
        self.rutton = tk.Button(text="Submit", command=self.getcontent)  
        self.tex.pack()
        self.rutton.pack()
        window.mainloop()
    def get2(self) :
        global va
        va = self.tex.get("1.0","end-1c") #text of file????
        print(va)
        self.tex.delete("1.0","end-1c")
        self.mainline.config(text="Finally, write the name of the file! TIP: Include the file extension (usually .txt)")
        self.rutton.config(text="Finish", command=self.finale)
    def finale(self) :
        v = self.tex.get("1.0","end-1c")
        f = open(v, "w")
        f.write(va)
        f.close()
        self.mainline.config(text="Thank you! Your file has been saved in the folder this program is in!")
        t.sleep(5)
        window.quit()
    def open(self) :
        global getch
        getch = self.tex.get("1.0","end-1c")
        self.tex.delete("1.0","end-1c")
        file = open(getch,"r").read()
        self.tex.insert(0.0, file)
        self.mainline.config(text="Enter your changes, and click save when you finish!")
        self.rutton.config(text="Save and Finish",command=self.fin)
    def fin(self) :
        global meh
        meh = self.tex.get("1.0","end-1c")
        wfile = open(getch, "w")
        wfile.write(meh)
        wfile.close()
        self.mainline.config(text="Thank you! Your file has been saved in the folder this program is in!")
        t.sleep(5)
        window.quit()
cont = Mainitee()
cont.main()
